<?php
/**
 * load framework required file
 * define FRAMEWORK_VERSION
 */
defined( 'ABSPATH' ) || exit;

define( 'FRAMEWORK_VERSION', '1.10.0' );

require FRAMEWORK_PATH . '/core/wpcom.php';